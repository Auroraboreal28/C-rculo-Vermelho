function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
function setup() {
  createCanvas(400, 400);  // Cria uma tela de 400x400 pixels
}
function draw() {
  background(220);  // Preenche o fundo com a cor cinza claro (220)
}
function draw() {
  background(220);  // Limpa o fundo
  
  fill(255, 0, 0);  // Cor de preenchimento vermelha
  ellipse(200, 200, 100, 100);  // Desenha um círculo no centro (200, 200) com raio 50
}
function draw() {
  background(220);  // Limpa o fundo
  
  fill(255, 0, 0);  // Cor de preenchimento vermelha
  ellipse(mouseX, mouseY, 100, 100);  // Círculo segue a posição do mouse
}
let x = 0;  // Posição inicial do círculo
let speed = 2;  // Velocidade de movimento

function draw() {
  background(220);  // Limpa o fundo
  
  fill(255, 0, 0);  // Cor de preenchimento vermelha
  ellipse(x, 200, 100, 100);  // Desenha o círculo na posição x
  
  x += speed;  // Move o círculo para a direita
  
  // Se o círculo alcançar o fim da tela, inverte a direção
  if (x > width || x < 0) {
    speed = -speed;
  }
}